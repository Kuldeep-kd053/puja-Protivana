package Pages;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import java.util.ArrayList;

public class Landing_Page {

    static WebDriver driver;


    public void L_page() throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        String track = "https://trkr.bitdriverupdater.com/btdu/45_58_56_226.txt";
        driver.get("http://cc.bitdriverupdater.com/productprice.svc/gtipinfo");
        String ip = driver.findElement(By.xpath("//pre[@style='word-wrap: break-word; white-space: pre-wrap;']")).getText();
        System.out.println("ip:" +ip);
        ((JavascriptExecutor)driver).executeScript("window.open()");
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(tabs.size()-1));
        driver.get("https://www.bitgamebooster.com/bgb/bitgame/8/?utm_source=btgbgpubing&p=BTG6024_BTG5877_RUNT&utm_medium=bing&driver_nm=&utm_campaign=Btgmgpu_usa_bing&at=&utm_pubid=btgmgpu_usa_adg1-82532462996665&va=o&vb=b&vc=c&ctx=&msclkid=20oct");
        System.out.printf(driver.findElement(By.xpath("//a[@class='btns']")).getAttribute("href"));
driver.findElement(By.xpath("//a[@class='btn btn2']")).click();
        driver.switchTo().window(tabs.get(tabs.size()-2));
        driver.get(track);
        String UTM_track= driver.findElement(By.xpath("//pre[@style='word-wrap: break-word; white-space: pre-wrap;']")).getText();
        System.out.printf(UTM_track);
//        List<WebElement> elements = driver.findElements(By.tagName("a"));
//        for (int i = 0; i < elements.size(); i++) {
//            System.out.println(elements.get(i).getAttribute("href"));

//After install page URL
         driver.get("https://www.bitgamebooster.com/inw/install/bit-game-booster/?utm_source=btgbgpubing&utm_campaign=" +
                 "Btgmgpu_usa_bing&utm_medium=bing&utm_pubid=btgmgpu_usa_adg1-82532462996665&p=BTG6024_BTG5877_RUNT&ctx=" +
                 "&at=&bs=&msclkid=20oct&gclid=&ud=-2226373677293726969&va=o&vb=b&vc=c&xip=216.189.157.167&xdt=" +
                 "19-11-2023+22%3a18%3a04&ftc=0&mpid=168&cid=us");
         driver.findElement(By.xpath("//a[contains(text(),'Upgrade to PRO Edition')]")).click();
        String price_page_url =driver.getCurrentUrl();
        System.out.println("price page URL:" +price_page_url );
        driver.get(price_page_url+"testmode=1");
    }
    }
