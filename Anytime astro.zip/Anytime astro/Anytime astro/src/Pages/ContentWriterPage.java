package Pages;

import org.openqa.selenium.WebDriver;

public class ContentWriterPage {
    WebDriver driver;
    public ContentWriterPage(WebDriver driver) {
        this.driver = driver;
    }

    public static String Content_writer_name = "contentwriter@malinator.com";
    public static String Content_writer_pass = "0";
    public static String[] Content_writer_per_list = {"Experts", "Expert Profiles", "Chat Reviews", "Add New Review",
            "Psychic Profile Review", "Live Session Category", "Live Session Type", "Category Alias"};
}
