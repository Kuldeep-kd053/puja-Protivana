package Pages;

import Test.LaunchBrowserPage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class PujaPurchasePage extends LaunchBrowserPage {
    @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//*[contains(text(),'Puja Purchase')]")
    public
    static WebElement puja_purchase;
    @FindBy(how = How.XPATH, using = "//p[contains(text(),'aman ss  ')]//preceding::a[contains(text(),'Mark Refunded')]")
    public
    static WebElement mark_refunded;
    @FindBy(how = How.XPATH, using = "//p[contains(text(),'aman ss  ')]//preceding::a[contains(text(),'Refunded')]")
    public
    static WebElement Refunded;
}
