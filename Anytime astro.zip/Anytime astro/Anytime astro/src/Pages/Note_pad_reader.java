package Pages;

public class Note_pad_reader {
}
