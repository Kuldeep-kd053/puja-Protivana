package Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import java.util.List;

public class SuperAdminPermissionpage {
    // super admin
    public static String superAdmin_name = "kuldeep@innovanathinklabs.com";
    public static String superAdmin_pass = "0";

    public static String[] super_admin_per_list = {"Home", "Experts", "Expert Profiles", "Registrations", "Chat Reviews",
            "Chat Report", "Attendance Report", "Account deletion Request", "Coupon Master", "Psychic Calls",
            "Chat Invite Summary", "Customer Spam Report", "Missed Chat Report", "Add New Review", "Language Config",
            "Master Config", "AdminUsers", "Customers", "Psychic Profile Review", "Expert Performance", "Payout",
            "First Purchase Report", "Call Chat Report", "Manual Payment Deduction", "Notice Board", "Notice Board List",
            "Occasion", "Welcome Message Request", "Deeplink", "Update Bank-Detail", "Bank-Detail List",
            "Expert Insights Summary", "Performance Dashboard", "Expert Badge", "User Permissions", "Live Session Category",
            "Live Session Type", "Live Session Report", "Schedule Live Session", "Create Deals", "Category Alias",
            "Payments", "Registration","Expert Image Review","Expert Image Updates","Pending Questions","Puja Purchase", "Expert Summary","Question Report"
         };
    //

    @FindBy(how = How.XPATH,using = "//table[@class='table bg-white datatable']//td[1]")
    public static List<WebElement> AdminUser_Email_List;
}
