package Pages;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class Switchtab {

    public static String str = "Win Riser - Best anti-malware software for Windows PC";
    static WebDriver driver;

    public static void main(String[] args) throws InterruptedException, FileNotFoundException {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        //WebDriver driver = new ChromeDriver();
        driver.get("https://www.winriser.com/");
        // wait of 5 seconds
       // driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        // Keys.Chord string
        String clickl = Keys.chord(Keys.CONTROL,Keys.ENTER);
        // open the link in new tab, Keys.Chord string passed to sendKeys
        driver.findElement(
                By.xpath("//a[@class='banner-button bg-white text-dark']")).click();
        Thread.sleep(1000);
        // hold all window handles in array list
        ArrayList<String> newTb = new ArrayList<String>(driver.getWindowHandles());
        //switch to new tab
        driver.switchTo().window(newTb.get(1));
        System.out.println("Page title of new tab: " + driver.getTitle());
        //switch to parent window
        driver.switchTo().window(newTb.get(0));
        System.out.println("Page title of parent window: " + driver.getTitle());
        Assert.assertEquals(str,driver.getTitle(),"assertion failed");
        Thread.sleep(5000);
        driver.findElement(By.xpath("//a[@class='nav-link scrollPage contactus  h-style-head']")).sendKeys(clickl);
        System.out.println("yeah done bro,carry on");
        Thread.sleep(5000);
        driver.quit();
        File file = new File("D:/Projects/Automation/deep_excel.xlsx");
    }
}