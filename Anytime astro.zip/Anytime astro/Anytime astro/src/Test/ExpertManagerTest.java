package Test;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static Pages.ExpertManagerPage.*;
import static Pages.SuperAdminPermissionpage.superAdmin_name;
import static Pages.SuperAdminPermissionpage.superAdmin_pass;


public class ExpertManagerTest extends LaunchBrowserPage {

    @Test(priority = 1)
    public void verify_ExpertManager_permission() throws InterruptedException {
        AdminPermissionPage adminPermissionPage = PageFactory.initElements(driver, AdminPermissionPage.class);
        driver.get(Login_page_url);
        user_login(ExpertManager_name, ExpertManager_pass);
        user_avtar.click();
        String user_name = username.getText();
        Thread.sleep(7000);
        Assert.assertEquals(user_name, ExpertManager_name);
        System.out.println("login successful with: " + user_name);

        List<String> all_elements_text = new ArrayList<>();

        for (WebElement webElement : permission_list) {
            all_elements_text.add(webElement.getText());
        }

        String[] str = new String[all_elements_text.size()];

        for (int i = 0; i < all_elements_text.size(); i++) {
            str[i] = all_elements_text.get(i);
        }

        if (Arrays.toString(str).equals(Arrays.toString(ExpertManager_per_list)))

            System.out.println("verified given permission: " + str.length);
        else
            System.out.println("not verified given permission: " + ExpertManager_per_list.length);
        Assert.assertEquals(str.length, ExpertManager_per_list.length, "problem with admin user permission");
        adminPermissionPage.Open_Chat_Report_permission();
    }

    @Test(priority = 2)
    public static void home_permission_click() {
        AdminPermissionPage adminPermissionPage = PageFactory.initElements(driver, AdminPermissionPage.class);
        adminPermissionPage.Open_Chat_Report_permission();
        System.out.printf("vow kuldeep that's great success");
        driver.quit();


    }


}
