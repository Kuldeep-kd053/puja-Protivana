package Test;

import com.beust.ah.A;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;



public class Pooja extends LaunchBrowserPage {
    public static String Puja_URL = "https://puja.anytimeastro.com/products";
    @FindBy(how = How.XPATH, using = "//div[@class='product-box']")
    public static List<WebElement> ProductList;
    @FindBy(how = How.XPATH, using = "//span[contains(text(),'Choose Option')]")
    public static WebElement product;
    @FindBy(how = How.XPATH, using = "//*[@class='closebtn']")
    public static WebElement Close_Cart;
    @FindBy(how = How.XPATH, using = "//div[@class='box-text']")
    public static WebElement choose_option;

    @FindBy(how = How.XPATH, using = "//span[@class='product-add-to-cart-button-name']")
    public static List<WebElement> price_button_option;
    @FindBy(how = How.XPATH, using = "//div[@class='container']//div[@class='product-box']")
    public static WebElement scroll_element;
    @FindBy(how = How.CLASS_NAME, using = "col-12 mb-3")
    public static WebElement All_product;





    @Test
    public static void get_pooja_name() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.get(Puja_URL);
        List<String> all_elements_text = new ArrayList<>();



        for (WebElement webElement : ProductList) {
            all_elements_text.add(webElement.getText());
            System.out.println(webElement.getText());
            driver.navigate().refresh();
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", All_product);
            Thread.sleep(6000);
            choose_option.sendKeys(Keys.TAB);
            webElement.click();
            String gender = driver.findElement(By.xpath("//b[contains(text(), 'Gender:')]")).getText().trim();
            System.out.println(gender);

            driver.navigate().back();

        }

        System.out.println(all_elements_text);
        System.out.println("Total number of puja" + all_elements_text.size());

    }
}

//  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Choose Option')]")));
//WebElement puja = wait.until(ExpectedConditions.elementToBeClickable(webElement));
//  scrollElementByPixels(driver, webElement, 200); // Adjust the pixel value as needed
//  puja.click();
// String gender = driver.findElement(By.xpath("//b[contains(text(), 'Gender:')]")).getText().trim();
// driver.navigate().back();
// Close_Cart.click();
//public static void scrollElementByPixels(WebDriver driver, WebElement element, int pixels) {
//    // Create an instance of JavascriptExecutor
//    JavascriptExecutor js = (JavascriptExecutor) driver;
//
//    // Scroll the element by a fixed number of pixels
//    js.executeScript("arguments[0].scrollBy(0, arguments[1]);", element, pixels);
//}
