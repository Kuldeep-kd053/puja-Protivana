package Test;
import org.openqa.selenium.By;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class Window_TabHandling extends LaunchBrowserPage {


    public static void switch_window() throws InterruptedException {
        driver.manage().deleteAllCookies();
        Thread.sleep(9000);
        driver.get("https://www.anytimeastro.com/");
//        driver.get("https://www.google.com/");
//        ((JavascriptExecutor) driver).executeScript("window.open()");
//        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
//        System.out.println("number of opened tab: "+tabs.size());
//        driver.switchTo().newWindow(WindowType.WINDOW);
//        driver.switchTo().window(tabs.get(1));
//        driver.get("https://www.browserstack.com/");
//        driver.get("https://www.google.com/");
//        System.out.println("number of opened tabs: "+tabs.size());
//        driver.switchTo().window(tabs.get(0));}
    }

    @Test

    public static void feth_all_urls() throws InterruptedException, IOException {
        driver.manage().deleteAllCookies();

        driver.get("https://www.anytimeastro.com/");
        //Get list of web-elements with tagName  - a

        List<WebElement> jobLinks =driver.findElements(By.tagName("a"));
        List<String> texts = new ArrayList<String>();

        for (WebElement element : jobLinks) {
            texts.add(element.getText());
        }
        System.out.println("this is what i want : " +texts);

        }

    }

