package Test;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.*;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.List;

public class LaunchBrowserPage {
    public static WebDriver driver;
    @FindBy(how = How.XPATH, using = "(//li[@class='namedisplay d-flex justify-content-center align-items-center']//div//h3)[1]")
    public static WebElement username;
    @FindBy(how = How.XPATH, using = "//li[@class='list-inline-item']//div[@class='dropdown']")
    public static WebElement user_avtar;
    public static String Login_page_url = "https://oadmin.anytimeastro.com/account/adminlogin";
    @FindBy(how = How.NAME, using = "Email")
    static
    WebElement Username;
    @FindBy(how = How.NAME, using = "Password")
    static
    WebElement password;
    @FindBy(how = How.XPATH, using = "//div[@class='col-md-12 mt-3 mb-5']//input")
    static
    WebElement login_button;
    @FindBy(how = How.CLASS_NAME, using = "custom-control-label")
    static WebElement remember_me;
    @FindBy(how = How.XPATH, using = "//div[@class='menu_list']//li")
    List<WebElement> permission_list;


    @BeforeClass
    public void setup(@Optional("chrome") String browser) throws Exception {
        if (browser.equalsIgnoreCase("firefox")) {

            driver = new FirefoxDriver();

        } else if (browser.equalsIgnoreCase("chrome")) {
            ChromeOptions options = new ChromeOptions();
            options.addArguments();
            driver = new ChromeDriver(options);
        } else if (browser.equalsIgnoreCase("Edge")) {
            driver = new EdgeDriver();
        } else {
            throw new Exception("Incorrect Browser");
        }

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.manage().window().maximize();
        PageFactory.initElements(driver, this);
        driver.get(Login_page_url);
        Thread.sleep(5000);
    }

    public static void user_login(String name, String pass) {
        driver.navigate().refresh();
        Username.clear();
        Username.sendKeys(name);
        password.clear();
        password.sendKeys(pass);
        remember_me.click();
        login_button.click();
        login_button.click();

    }

//    @AfterClass
//    public static void close_browser() {
//       driver.quit();
//
//   }
    public void TakeScreenShot() throws IOException {
        File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(screenshot, new File("D:\\Yammy" + Math.random() + ".jpg"));
        System.out.println("screen captured  o yeah..");
    }
}
//        ChromeOptions options = new ChromeOptions();
//        options.addArguments("disable-infobars");
//        options.addArguments("--lang=en");
//        options.addArguments("--no-sandbox");
//        options.addArguments("--disable-dev-shm-usage");
//        options.addArguments("--start-maximized");
//        options.addArguments("--disable-popup-blocking");
//        WebDriverManager.chromedriver().clearDriverCache().setup();
//        WebDriverManager.firefoxdriver().clearDriverCache().setup();
//        WebDriverManager.edgedriver().clearDriverCache().setup();
//  WebDriverManager.chromedriver().setup();
//driver = new ChromeDriver();