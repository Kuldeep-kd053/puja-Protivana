package Test;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static Pages.CampaignPage.*;

public class CampaignTest extends LaunchBrowserPage {


    @Test
    public void verify_campaign_permission() throws InterruptedException {
        user_login(Campaign_name, Campaign_pass);
        user_avtar.click();
        String user_name = username.getText();
        System.out.println(user_name + "This is the logged user");
        Thread.sleep(8000);
        Assert.assertEquals(user_name, Campaign_name);

        List<String> all_elements_text = new ArrayList<>();

        for (WebElement webElement : permission_list) {
            all_elements_text.add(webElement.getText());
        }

        String[] str = new String[all_elements_text.size()];

        for (int i = 0; i < all_elements_text.size(); i++) {
            str[i] = all_elements_text.get(i);
        }

        if (Arrays.toString(str).equals(Arrays.toString(Campaign_per_list)))

            System.out.println("verified given permissions: " + str.length);
        else
            System.out.println("not verified given permissions: " + Campaign_per_list.length);
        Assert.assertEquals(str.length, Campaign_per_list.length, "problem with admin user permission");

    }

}
