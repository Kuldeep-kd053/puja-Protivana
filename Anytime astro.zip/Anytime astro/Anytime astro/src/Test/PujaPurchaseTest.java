package Test;

import Pages.PujaPurchasePage;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import static Pages.PujaPurchasePage.*;
import static Pages.SuperAdminPermissionpage.superAdmin_name;
import static Pages.SuperAdminPermissionpage.superAdmin_pass;
public class PujaPurchaseTest extends LaunchBrowserPage{


        @Test
        public static void open_puja_Purchase() throws InterruptedException {
           AdminPermissionPage adminPermissionPage = PageFactory.initElements(driver, AdminPermissionPage.class);
          PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver,PujaPurchasePage.class);
            user_login(superAdmin_name,superAdmin_pass);
            Thread.sleep(3000);
            puja_purchase.click();

            String refund_status = mark_refunded.getText();

            if(mark_refunded.isDisplayed()){
                System.out.println("Refund not done:");
            }
            else if (Refunded.isDisplayed()) {
                    System.out.println("Refunded:");
            }
            else {
                System.out.println("Refund status not found");
            }
        }
    }

