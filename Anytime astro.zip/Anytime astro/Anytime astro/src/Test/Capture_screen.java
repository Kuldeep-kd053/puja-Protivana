package Test;

import Test.LaunchBrowserPage;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Random;


public class Capture_screen extends LaunchBrowserPage {

        public static void take_screenshot() throws IOException {
        File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(screenshot, new File("D:\\Yammy"+ Math.random() +".jpg"));
        System.out.println("screen captured  o yeah..");
            System.out.println("This is the path of screenshot file :"+screenshot.getAbsolutePath());
            System.out.println(screenshot.getName());
            System.out.println(screenshot.getCanonicalPath());

    }
}

