package Test;

public class MarketingManagerTest {
}
